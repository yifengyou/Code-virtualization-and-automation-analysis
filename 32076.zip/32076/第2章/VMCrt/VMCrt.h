
#define VREG_RAX	0
#define VREG_RCX	1
#define VREG_RDX	2
#define VREG_RBX	3
#define VREG_RSP	4
#define VREG_RBP	5
#define VREG_RSI	6
#define VREG_RDI	7

enum opcode_id{
	op_mov = 0,
	op_add,
	op_exit
};
